declare module 'hume' {
  const Hume: any;
  export = Hume;
}
