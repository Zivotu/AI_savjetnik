declare module 'openai' {
  const OpenAI: any;
  export default OpenAI;
}
